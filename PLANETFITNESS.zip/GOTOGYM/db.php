<?php
$server="localhost";
$username="root";
$password="";
$database="gym1";

$conn=mysqli_connect($server,$username,$password,$database);

?>

